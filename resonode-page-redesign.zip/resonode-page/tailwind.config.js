module.exports = {
  content: ["./pages/**/*.js", "./components/**/*.js"],
  theme: {
    colors: {
      transparent: "transparent",
      black: {
        500: "#4F5665",
        600: "#0B132A",
      },
      orange: {
        500: "#F53855",
      },
      white: {
        300: "#F8F8F8",
        500: "#fff",
      },
      gray: {
        500: "#DDDDDD",
	700: "#717579",
      },
    },
    extend: {
      fontFamily: {
        mono: ["JetBrains Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
