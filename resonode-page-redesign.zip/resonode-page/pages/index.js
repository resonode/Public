import Head from "next/head";
import Layout from "../components/Layout/Layout";
import Hero from "../components/Hero";
import Feature from "../components/Feature";
import Pricing from "../components/Pricing";

export default function Home() {
  return (
    <>
      <Head>
        <title>ResoNode</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Layout>
        <Hero />
        <Feature />
        <Pricing />
      </Layout>
    </>
  );
}
