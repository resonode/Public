import ButtonPrimary from "./misc/ButtonPrimary";

const plans = [
  { name: "1-Month", price: "RM 7.50", popular: false },
  { name: "6-Month", price: "RM 37.50", popular: true },
  { name: "1-Year", price: "RM 75.00", popular: false },
];

const specs = [
  "2 vCPU Core",
  "4 GB RAM",
  "50 GB NVMe SSD",
  "Unmetered Bandwidth",
  "1 Free Subdomain",
];

const Pricing = () => (
  <div className="w-full py-14" id="pricing">
    <div className="max-w-screen-xl px-6 sm:px-8 lg:px-16 mx-auto text-center">
      <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white-500 leading-relaxed">
        Linux - CLI Edition
      </h3>
      <p className="leading-normal w-10/12 sm:w-7/12 mx-auto my-2 text-white-500">
        Pay for what you use, with absolutely no subscription traps.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8">
        {plans.map((plan) => (
          <div
            key={plan.name}
            className={
              "relative flex flex-col items-center bg-black-600/40 py-10 px-6 border " +
              (plan.popular ? "border-orange-500" : "border-gray-500/30")
            }
          >
            {plan.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-orange-500 text-white-500 font-mono text-xs uppercase tracking-wider px-3 py-1">
                Popular
              </span>
            )}
            <p className="text-lg text-white-500 font-bold my-2">{plan.name}</p>
            <p className="text-2xl text-white-500 mb-4">{plan.price}</p>
            <ul className="font-mono text-white-500 text-sm space-y-1 text-left">
              {specs.map((spec) => (
                <li key={spec}>
                  <span className="text-orange-500">{">"} </span>
                  {spec}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div id="inquiry" className="py-12 border-t border-gray-500/20 mt-6">
        <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white-500 leading-relaxed">
          Have a Question?
        </h3>
        <p className="leading-normal mx-auto my-2 w-10/12 sm:w-7/12 text-white-500">
          Send us an inquiry and we'll get back to you by email.
        </p>
        <div className="mt-6">
          <ButtonPrimary href="">Send Inquiry</ButtonPrimary>
        </div>
      </div>
    </div>
  </div>
);

export default Pricing;
