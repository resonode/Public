const ButtonPrimary = ({ children, href }) => {
  const className =
    "inline-block py-3 px-12 text-white-500 font-semibold rounded-sm bg-black-600 border border-gray-500/30 hover:opacity-90 transition-all outline-none";

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={className}>
        {children}
      </a>
    );
  }

  return <button className={className}>{children}</button>;
};

export default ButtonPrimary;
