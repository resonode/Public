const ButtonOutline = ({ children }) => (
  <button className="font-medium py-2 px-6 border border-black-500 text-white-500 rounded-sm hover:bg-black-500 hover:text-white-500 transition-all outline-none">
    {children}
  </button>
);

export default ButtonOutline;
