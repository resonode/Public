import ButtonPrimary from "./misc/ButtonPrimary";

const Hero = () => (
  <div className="max-w-screen-xl mt-24 px-8 xl:px-16 mx-auto" id="about">
    <div className="flex flex-col items-start py-16">
      <p className="font-mono text-orange-500 text-sm sm:text-base mb-4">
        $ ssh user@resonode.net
      </p>
      <h1 className="text-3xl lg:text-5xl font-bold tracking-tight text-white-500 leading-tight">
        Malaysia's Dedicated Student VPS Provider
      </h1>
      <p className="text-white-500 mt-4 mb-6 max-w-xl">
        Ultra affordable Linux VPS built for student budgets. With our VPS, students can use their skills and imagination to be a Malaysian innovator.
      </p>
      <ButtonPrimary href="https://forms.gle/4ezx6aWCUGpd5XEp9">
        Purchase Now
      </ButtonPrimary>
    </div>
  </div>
);

export default Hero;
