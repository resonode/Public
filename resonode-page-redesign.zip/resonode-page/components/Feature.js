const features = [
  {
    tag: "01",
    text: "Make your systems publicly accessible from anywhere via the internet for seamless grading and demonstrations",
  },
  {
    tag: "02",
    text: "Perfect for hosting Web Applications, Data Analytics engines, IoT backends, APIs, and automated workflows (such as n8n)",
  },
  {
    tag: "03",
    text: "Can be configured as a custom reverse proxy or private routing environment to secure your architecture",
  },
  {
    tag: "04",
    text: "Eliminate the need to keep a physical local machine running 24/7 to host your services (zero hardware overhead)",
  },
];

const Feature = () => (
  <div
    className="max-w-screen-xl mt-8 mb-6 sm:mt-14 sm:mb-14 px-6 sm:px-8 lg:px-16 mx-auto"
    id="feature"
  >
    <h3 className="text-3xl lg:text-4xl font-bold tracking-tight text-white-500 leading-relaxed">
      Innovate Inside The Box
    </h3>
    <p className="my-2 font-mono text-orange-500 text-sm uppercase tracking-wider">
      Why deploy your project on a VPS?
    </p>

    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
      {features.map((item) => (
        <div
          key={item.tag}
          className="border border-gray-500/30 bg-black-600/40 px-6 py-5 flex gap-4"
        >
          <span className="font-mono text-orange-500 font-bold">{item.tag}</span>
          <p className="text-white-500">{item.text}</p>
        </div>
      ))}
    </div>
  </div>
);

export default Feature;
