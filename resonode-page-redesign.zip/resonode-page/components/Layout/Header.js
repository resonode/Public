import { useState } from "react";
import { Link as ScrollLink } from "react-scroll";

const navItems = [
  { id: "about", label: "About" },
  { id: "feature", label: "Feature" },
  { id: "pricing", label: "Pricing" },
  { id: "inquiry", label: "Inquiry" },
];

const Header = () => {
  const [activeLink, setActiveLink] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full z-30 bg-black-600 border-b border-gray-500/20">
      <nav className="max-w-screen-xl px-6 sm:px-8 lg:px-16 mx-auto flex items-center justify-between py-3 sm:py-4 relative">
        <img src="/Logo.png" alt="Logo" className="h-8 lg:h-12 w-auto" />

        <button
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle navigation menu"
          className="flex flex-col justify-center gap-1.5 w-8 h-8 lg:w-12 lg:h-12"
        >
          <span className="block h-0.5 w-full bg-white-500"></span>
          <span className="block h-0.5 w-full bg-white-500"></span>
          <span className="block h-0.5 w-full bg-white-500"></span>
        </button>

        {menuOpen && (
          <ul className="absolute top-full right-6 sm:right-8 lg:right-16 mt-2 bg-black-600 border border-gray-500/30 py-2 text-white-500 font-mono text-sm uppercase tracking-wider">
            {navItems.map((item) => (
              <li key={item.id}>
                <ScrollLink
                  to={item.id}
                  spy={true}
                  smooth={true}
                  duration={1000}
                  onSetActive={() => setActiveLink(item.id)}
                  onClick={() => setMenuOpen(false)}
                  className={
                    "block px-8 py-2 cursor-pointer whitespace-nowrap transition-all " +
                    (activeLink === item.id
                      ? "text-orange-500"
                      : "hover:text-orange-500")
                  }
                >
                  {item.label}
                </ScrollLink>
              </li>
            ))}
          </ul>
        )}
      </nav>
    </header>
  );
};

export default Header;
