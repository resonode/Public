import { FaFacebook, FaInstagram, FaTiktok, FaLinkedin } from "react-icons/fa6";

const socialLinks = [
  { name: "Facebook", href: "https://www.facebook.com/share/1H5zM18JFz/?mibextid=wwXIfr", Icon: FaFacebook },
  { name: "Instagram", href: "https://www.instagram.com/resonode.vps?igsh=MXV0b3lyZXl6Yjk4Zw==", Icon: FaInstagram },
  { name: "TikTok", href: "https://tiktok.com/", Icon: FaTiktok },
  { name: "LinkedIn", href: "https://www.linkedin.com/company/resonode/", Icon: FaLinkedin },
];

const Footer = () => (
  <footer className="py-12 mt-12 border-t border-gray-500/20">
    <div className="max-w-screen-xl mx-auto px-6 sm:px-8 lg:px-16 text-center text-white-500">
      <div className="flex justify-center gap-6 mb-4">
        {socialLinks.map(({ name, href, Icon }) => (
          <a
            key={name}
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={name}
            className="text-white-500 hover:text-orange-500 transition-all"
          >
            <Icon size={22} />
          </a>
        ))}
      </div>
      <p className="font-mono text-sm text-white-500/70">
        &copy; {new Date().getFullYear()} ResoNode
      </p>
    </div>
  </footer>
);

export default Footer;
